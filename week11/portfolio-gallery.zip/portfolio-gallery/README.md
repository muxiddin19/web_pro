# Portfolio Gallery

## Use these files
1. Create the project:  npx create-react-app portfolio-gallery
2. Copy the `src/` folder from this download over the project's `src/` folder.
3. Run:  cd portfolio-gallery && npm start
4. Edit `src/data/projects.js` and put in YOUR deployed projects.
